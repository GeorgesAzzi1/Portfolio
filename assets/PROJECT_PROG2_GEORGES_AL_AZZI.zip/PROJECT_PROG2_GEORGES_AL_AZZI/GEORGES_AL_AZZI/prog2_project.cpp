#include<iostream>
#include<cstring>
#include<string>
#include<iomanip>
#include<fstream>
#include<sys/stat.h>
#include<chrono>
#include <algorithm>
#include<sstream>
#include <cstdio>
#include<cmath>


using namespace std;

struct date {
    string date;
    string time;

};
struct charity {
    int charityId;
    string charityName;
    string description;
    double targetAmount;
    double currentAmount;
    string status;
    date d;
};
struct donation {
    int donationId;
    int charityId;
    double amount;
    date d;
};
struct client {
    int userid;
    string firstname;
    string lastname;
    string phone;
    string email;
    string password;
    int nbDonation;
    donation* donations;

};





bool fileExists(const string& filename) {
    struct stat buffer;
    return (stat(filename.c_str(), &buffer) == 0);
}
bool file() {
    if (!fileExists("charity.txt")) {
        fstream file("charity.txt", ios::app);
        if (!file.is_open()) {
            cout << "Failed to open file." << endl;
            return false;
        }





        file.close();
    }
    if (!fileExists("client.txt")) {
        fstream files("client.txt", ios::out);
        if (!files.is_open()) {
            cout << "Failed to open file." << endl;
            return false;
        }




        files.close();
    }
    if (!fileExists("donations.txt")) {
        fstream file("donations.txt", ios::app);
        if (!file.is_open()) {
            cout << "Failed to open file." << endl;
            return false;
        }







        file.close();
    }
    return 0;
}
int generateUniqueUserID() {
    int newID;
    srand(time(0));
    newID = 10 + rand() % 100;





    return newID;
}
bool password(string password) {

    int num = 0, cap = 0, lower = 0, special = 0;
    int size = password.length();

    for (int i = 0; i < size; i++) {
        if (isdigit(password[i])) {
            num = 1;
        }
        else if (isupper(password[i])) {
            cap = 1;
        }
        else if (islower(password[i])) {
            lower = 1;
        }
        else if (password[i] == '!' || password[i] == '@' || password[i] == '#' || password[i] == '$' || password[i] == '%' || password[i] == '*' || password[i] == '~' || password[i] == '^') {
            special = 1;
        }
    }

    if (num == 1 && cap == 1 && lower == 1 && special == 1 && size >= 8) {
        return true;
    }
    else
        return false;
}
bool address(string& add) {
    int At = 0;
    int Dot = 0;

    for (int i = 0; i < add.length(); i++) {
        if (add[i] == '@') {
            At = i;
        }
        else if (add[i] == '.') {
            Dot = i;
        }
    }
    if (At != 0 && Dot != 0 && At < Dot && Dot < add.length() - 1) {
        string domain = add.substr(At + 1, Dot - (At + 1));
        if (domain == "gmail" || domain == "hotmail" || domain == "live") {
            return true;
        }
    }

    return false;
}
bool PhoneNumber(string phonenumber) {

    if (phonenumber.length() != 8) {
        return false;
    }


    for (int i = 0; i < 8; i++) {

        if (isdigit(phonenumber[i])) {
            return true;
        }
    }

    return false;
}

int generateUniqueDonationID() {

    donation donations;
    int maxId = 0;

    fstream file("donations.txt", ios::in);
    if (!file.is_open()) {
        cout << "Failed to open the donation file." << endl;
        
    }
    else
    {
        while (file >> donations.donationId >> donations.charityId >> donations.amount >> donations.d.date >> donations.d.time) {
            if (donations.donationId > maxId) {
                maxId = donations.donationId;

            }
        }
    }
    file.close();
    return maxId + 1;
}

string getCurrentDate() {
    time_t now = time(0);
    tm localTime;
    localtime_s(&localTime, &now);

    char dateBuffer[20];
    strftime(dateBuffer, sizeof(dateBuffer), "%d-%m-%Y", &localTime);

    return string(dateBuffer);
}
    
string getCurrentTime() {
    time_t now = time(0);
    tm localTime;
    localtime_s(&localTime, &now);

    char timeBuffer[10];
    strftime(timeBuffer, sizeof(timeBuffer), "%H:%M", &localTime);

    return string(timeBuffer);
}

void add_donation()
{

    charity c;
    donation temp;
    donation d;
    temp.donationId = generateUniqueDonationID();
    temp.d.date = getCurrentDate();
    temp.d.time = getCurrentTime();

    cout << "Please enter the charityId: ";
    cin >> temp.charityId;

    cout << "Please enter the amount of your donation: ";
    cin >> temp.amount;

    fstream inputfile("donations.txt", ios::in | ios::app);
    if (!inputfile.is_open()) {
        cout << "Failed to open file." << endl;
    }

    fstream file("charity.txt", ios::in | ios::app);
    if (!file.is_open()) {
        cout << "Failed to open file." << endl;
    }

    bool statusFound = false;
    bool charityIdFound = false;
    while (file >> c.charityId >> c.charityName >> c.description >> c.targetAmount >> c.currentAmount >> c.d.date >> c.d.time >> c.status) {
        if (temp.charityId == c.charityId) {
            charityIdFound = true;
            if(c.status == "closed") {

                statusFound = true;

            }
        }
    }
    if (statusFound == true) {

        cout << "Sorry, this charity is closed. You can't donate at this time." << endl;


    }
    if(charityIdFound == true && statusFound == false) {
        inputfile << temp.donationId << "\t" << temp.charityId << "\t" << temp.amount << "\t" << temp.d.date << "\t" << temp.d.time << endl;

        cout << "donation added successfully\n";
    }
    cout << "the charityId that you entered " << temp.charityId << " isn't available." << endl;

    file.close();
    inputfile.close();


}

void deletedonation() {

    donation donations;
    donation temp;


    cout << "Enter the charityId of the donation you want to remove: ";
    cin >> temp.charityId;


    fstream file("donations.txt", ios::in);
    if (!file.is_open()) {
        cout << "Failed to open donations file." << endl;
        return;
    }

    fstream tempFile("temp.txt", ios::out);
    if (!tempFile.is_open()) {
        cout << "Failed to create temp file." << endl;
        file.close();
        return;
    }

    bool donationFound = false;

    while (file >> donations.donationId >> donations.charityId >> donations.amount >> donations.d.date >> donations.d.time) {
        if (temp.charityId == donations.charityId) {
            donationFound = true;
            cout << "the donation you put at the charity id " << donations.charityId << " has been deleted." << endl;
        }
        else {
            tempFile << donations.donationId << "\t" << donations.charityId << "\t" << donations.amount << "\t" << donations.d.date << "\t" << donations.d.time << endl;
        }
    }

    file.close();
    tempFile.close();

    if (donationFound) {
        remove("donations.txt");
        rename("temp.txt", "donations.txt");
    }
    else {
        cout << "the donation you put at that charityId " << donations.charityId << " not found." << endl;
        remove("temp.txt");
    }

}

void modifyamount() {
    donation donations;
    donation temp;


    cout << "enter the id of the donation: ";
    cin >> temp.donationId;

    do {

        cout << "Enter the new amount of your donation: ";
        cin >> temp.amount;

    } while (temp.amount < 0);

    ifstream inputFile("donations.txt");
    if (!inputFile.is_open()) {
        cout << "Failed to open chharity file." << endl;
        return;
    }

    ofstream tempFile("temp.txt");
    if (!tempFile.is_open()) {
        cout << "Failed to create temp file." << endl;
        inputFile.close();
        return;
    }


    bool donationidFound = false;
    while (inputFile >> donations.donationId >> donations.charityId >> donations.amount >> donations.d.date >> donations.d.time) {
        if (temp.donationId == donations.donationId) {
            donationidFound = true;
            donations.amount = temp.amount;
            cout << "donation with the donationId " << donations.charityId << " found. Modifying the donation information..." << endl;


        }
        tempFile << donations.donationId << "\t" << donations.charityId << "\t" << donations.amount << "\t" << donations.d.date << "\t" << donations.d.time << endl;
    }

    inputFile.close();
    tempFile.close();

    if (donationidFound) {
        remove("donations.txt");
        rename("temp.txt", "donations.txt");
        cout << "Donations information modified successfully." << endl;
    }
    else {
        cout << "the donation that have a charityid " << donations.donationId << " not found." << endl;
        remove("temp.txt");
    }

}


void modifyname() {

    donation donations;
    donation temp;
    charity c;
    charity tempc;
    donations.d.date = getCurrentDate();
    donations.d.time = getCurrentTime();

    cout << "enter the id of the donation: ";
    cin >> temp.donationId;

    cout << "enter the name of the charity: ";
    getline(cin, tempc.charityName);


    ifstream inputFile("charity.txt");
    if (!inputFile.is_open()) {
        cout << "Failed to open charity file." << endl;
        return;
    }
    ifstream inputfile("donations.txt");
    if (!inputfile.is_open()) {
        cout << "Failed to open donation file." << endl;
        return;
    }
    ofstream tempFile("temp.txt");
    if (!tempFile.is_open()) {
        cout << "Failed to create temp file." << endl;
        inputFile.close();
        inputfile.close();
        return;
    }


    int id;
    bool charityNameFound = false;
    bool donationIdFound = false;
    while (inputFile >> c.charityId >> c.charityName >> c.description >> c.targetAmount >> c.currentAmount >> c.d.date >> c.d.time >> c.status) {
        if (tempc.charityName == c.charityName) {

            charityNameFound = true;
            id = c.charityId;
        }
    }
    if (charityNameFound == true) {

        while (inputfile >> donations.donationId >> donations.charityId >> donations.amount >> donations.d.date >> donations.d.time) {
            if (temp.donationId == donations.donationId) {
                donationIdFound = true;
                donations.charityId = id;
            }
            tempFile << donations.donationId << "\t" << donations.charityId << "\t" << donations.amount << "\t" << donations.d.date << "\t" << donations.d.time << endl;
        }
    }
    inputFile.close();
    inputfile.close();
    tempFile.close();

    if (donationIdFound) {
        remove("donations.txt");
        rename("temp.txt", "donations.txt");
        cout << "Donations information modified successfully." << endl;
    }
    else {
        cout << "the charity name " << c.charityName << " or donationID " << temp.donationId << " not found." << endl;
        remove("temp.txt");
    }

}




void showcharities() {

    charity c;

    ifstream inputFile("charity.txt");
    if (!inputFile.is_open()) {
        cout << "Failed to open charity file." << endl;
        return;
    }
    while (inputFile >> c.charityId >> c.charityName >> c.description >> c.targetAmount >> c.currentAmount >> c.d.date >> c.d.time >> c.status)
    {
        cout << c.charityId << "\t" << c.charityName << "\t" << c.description << "\t" << c.targetAmount << "\t" << c.currentAmount << "\t" << c.d.date << "\t" << c.d.time << "\t" << c.status << endl;
    }

    inputFile.close();

}

int countDonations() {
    ifstream file("donations.txt");
    if (!file.is_open()) {
        cout << "Failed to open donations file." << endl;
        return 0;
    }

    string line;
    int count = 0;

    while (getline(file, line)) {
        if (!line.empty()) {
            count++;
        }
    }

    file.close();
    return count;
}

void Client(client s1) {
    int choice;
    int count;
    client c;
    


    showcharities();

    do {

        cout << "welcome, here are your privelege as a client: \n";
        cout << "1- place a donataion \n";
        cout << "2- remove a donation \n";
        cout << "3- modify the amount of the donation \n";
        cout << "4- modify the charity you wish to donate to\n";
        cout << "0- exit \n";



        cin >> choice;
        


        switch (choice) {
        case 1:cout << "you chose to place a donation:\n";
            cout << "how many times you wish to donate?: ";
                cin >> c.nbDonation;
            for (int i = 0;i < c.nbDonation;i++)
            {
               


                add_donation();
            }
            
            
            break;

        case 2:cout << "you chose to remove the donation:\n";
            deletedonation();
            break;

        case 3:cout << "you chose to modify the donation:\n";
            modifyamount();
            break;

        case 4:cout << "you chose to modify the charity you donated to:\n";
            modifyname();
            break;

        case 0:
            break;

        default:cout << "sry an error has occured,pls enter only from the given choice";
        }

    } while (choice != 0);
}


client account(client s1) {



    s1.userid = generateUniqueUserID();
    cout << "your Id will be: " << s1.userid << endl;
    cout << "Please enter your first name: ";
    cin.ignore();
    getline(cin, s1.firstname);


    cout << "Please enter your last name: ";
    getline(cin, s1.lastname);


    do {
        cout << "Please enter a password it should contain(8 char|1 capital |1 lowercase| 1 special): ";
        getline(cin, s1.password);
    } while (password(s1.password) != true);


    do {
        cout << "Please enter your email|(user@example.com)";
        getline(cin, s1.email);
    } while (address(s1.email) != true);


    do {
        cout << "Please enter phone number(12345678): ";
        getline(cin, s1.phone);
    } while (PhoneNumber(s1.phone) != true);


    fstream file("client.txt", ios::app);
    if (!file.is_open()) {
        cout << "Failed to open file." << endl;

    }

    file << "\n" << s1.userid << "\t" << s1.firstname << " " << s1.lastname << "\t" << s1.password << "\t" << s1.email << "\t" << s1.phone << endl;

    file.close();



    Client(s1);
    return s1;


}
int authentication(int& id, string& password) {

    client s;

    ifstream file("client.txt");
    if (!file.is_open()) {
        cout << "Failed to open client.txt file." << endl;
     
    }


    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        ss >> s.userid >> s.firstname >> s.lastname >> s.password >> s.email >> s.phone;


        if (id == s.userid && password == s.password && id < 5) {
            cout << "Welcome Administrator!" << endl;
            file.close();
            return 1;
        }
        if (id == s.userid && password == s.password && id >= 5) {
            cout << "Welcome Client!" << endl;
            file.close();
            return 2;
        }
    }

    cout << "Authentication failed. Invalid id or password.\n";
    file.close();
    return false;
}

void addcharity() {

    charity temp;
    charity c;


    cout << "Please enter the charityId: ";
    cin >> temp.charityId;

    cout << "Please enter the charityName: ";
    cin.ignore();
    getline(cin, temp.charityName);



    cout << "Please enter the description: ";
    
    getline(cin, temp.description);



    cout << "Please enter the targetAmount: ";

    cin >> temp.targetAmount;

    do { 
        cout << "Please enter the currentAmoumt: ";
        cin >> temp.currentAmount;
    } while (temp.currentAmount > temp.targetAmount);
    cout << "please enter the date: ";
    cin.ignore();
    getline(cin, temp.d.date);

    cout << "please enter the time: ";
    
    getline(cin, temp.d.time);


    cout << "please enter the status: ";
    
    getline(cin, temp.status);


    fstream file("charity.txt", ios::in | ios::app);
    if (!file.is_open()) {
        cout << "Failed to open file." << endl;
    }




    bool exists = false;
    while (file >> c.charityId >> c.charityName >> c.description >> c.targetAmount >> c.currentAmount >> c.d.date >> c.d.time >> c.status) {
        if (temp.charityId == c.charityId) {
            exists = true;
            cout << "Already exists" << endl;
            break;
        }
    }
    file.close();

    if (!exists) {
        fstream files("charity.txt", ios::app);
        if (!files.is_open()) {
            cout << "Failed to open file." << endl;
        }
        files << "\n" << temp.charityId << "\t" << temp.charityName << "\t" << temp.description << "\t" << temp.targetAmount << "\t" << temp.currentAmount << "\t" << temp.d.date << "\t" << temp.d.time << "\t" << temp.status << endl;
        cout << "charity added successfully\n";
        file.close();
    }

}
void deletecharity() {
    charity temp;
    charity c;
    cout << "Enter the charityId of the charity you want to remove: ";
    cin >> temp.charityId;

    fstream file("charity.txt", ios::in);
    if (!file.is_open()) {
        cout << "Failed to open charity file." << endl;
        return;
    }

    fstream tempFile("temp.txt", ios::out);
    if (!tempFile.is_open()) {
        cout << "Failed to create temp file." << endl;
        file.close();
        return;
    }

    bool charityFound = false;

    while (file >> c.charityId >> c.charityName >> c.description >> c.targetAmount >> c.currentAmount >> c.d.date >> c.d.time >> c.status) {
        if (temp.charityId == c.charityId) {
            charityFound = true;
            cout << "the charity with the charityIid: " << c.charityId << " has been deleted." << endl;
        }
        else {
            tempFile << c.charityId << "\t" << c.charityName << "\t" << c.description << "\t" << c.targetAmount << "\t" << c.currentAmount << "\t" << c.d.date << "\t" << c.d.time << "\t" << c.status<<endl;
        }
    }

    file.close();
    tempFile.close();

    if (charityFound) {
        remove("charity.txt");
        rename("temp.txt","charity.txt");
    }
    else {
        cout << "charity with charityId: " << c.charityId << " not found." << endl;
        remove("temp.txt");
    }

}
void modifycharity() {
    charity temp;
    charity c;
    cout << "Enter the charityId of the charity you want to modify: ";
    cin >> temp.charityId;

    ifstream inputFile("charity.txt");
    if (!inputFile.is_open()) {
        cout << "Failed to open charity file." << endl;
        return;
    }

    ofstream tempFile("temp.txt");
    if (!tempFile.is_open()) {
        cout << "Failed to create temp file." << endl;
        inputFile.close();
        return;
    }

    bool charityFound = false;

    while (inputFile >> c.charityId >> c.charityName >> c.description >> c.targetAmount >> c.currentAmount >> c.d.date >> c.d.time >> c.status) {
        if (temp.charityId == c.charityId) {
            charityFound = true;
            cout << "charity with charityId " << c.charityId << " found. \nModifying charity information..." << endl;
            int choice;
            do {
                cout << "What do you want to modify:" << endl;
                cout << "1- charityId" << endl;
                cout << "2- charityName" << endl;
                cout << "3- description" << endl;
                cout << "4- targetAmount" << endl;
                cout << "5- currrentAmount" << endl;
                cout << "6- date" << endl;
                cout << "7- time" << endl;
                cout << "8- status" << endl;
                cout << "0- Exit" << endl;
                cout << "Enter your choice: ";
                cin >> choice;
                


                switch (choice) {
                case 1:
                    cout << "Enter the new charityId of the charity: ";
                    cin >> temp.charityId;
                    c.charityId = temp.charityId;
                    break;
                case 2:
                    cout << "Enter the new charityName of the charity: ";
                    cin.ignore();
                    getline(cin, temp.charityName);
                    c.charityName = temp.charityName;
                    break;
                case 3:
                    cout << "Enter the new description of the charity: ";
                    cin.ignore();
                    getline(cin, temp.description);
                    c.description = temp.description;
                    break;
                case 4:
                    cout << "Enter the new targetAmount of the charity: ";
                    cin >> temp.targetAmount;
                    c.targetAmount = temp.targetAmount;
                    break;
                case 5:
                    cout << "Enter the new currentAmount of the charity: ";
                    cin >> temp.currentAmount;
                    c.currentAmount = temp.currentAmount;
                    break;
                case 6:
                    cout << "Enter the new date of the charity: ";
                    cin.ignore();
                    getline(cin, temp.d.date);
                    c.d.date = temp.d.date;
                    break;
                case 7:
                    cout << "Enter the new time of the charity: ";
                    cin.ignore();
                    getline(cin, temp.d.time);
                    c.d.time = temp.d.time;
                    break;
                case 8:
                    cout << "Enter the new status: ";
                    cin.ignore();
                    getline(cin, temp.status);
                    c.status = temp.status;
                    break;


                case 0:
                    break;
                default:
                    cout << "Invalid choice. Please try again." << endl;
                }
            } while (choice != 0);
        }
        tempFile << c.charityId << "\t" << c.charityName << "\t" << c.description << "\t" << c.targetAmount << "\t" << c.currentAmount << "\t" << c.d.date << "\t" << c.d.time << "\t" << c.status << endl;
    }

    inputFile.close();
    tempFile.close();

    if (charityFound) {
        remove("charity.txt");
        rename("temp.txt", "charity.txt");
        cout << "Charity information modified successfully." << endl;
    }
    else {
        cout << "charity with charityid " << c.charityId << " not found." << endl;
        remove("temp.txt");
    }

}

void administrator() {

    int choice;
    do {
        cout << "here are your privilege as an admin: \n";
        cout << "1-  add a charity \n";
        cout << "2- remove a charity \n";
        cout << "3- modify the charity information \n";
        cout << "0- exit \n";
        cin >> choice;
        switch (choice) {
        case 1:cout << "you chose to add a charity " << endl;
            addcharity();
            break;

        case 2:cout << "you chose to delete a charity "<< endl;
            deletecharity();
            break;

        case 3:cout << "you chose to modify the charity information"<<endl;
            modifycharity();
            break;
        case 0:
            break;

        default:cout << "The option you entered isn't available";
        }
    } while (choice != 0);
}


string simpleHash(const string& password) {
    unsigned long hash = 0;
    int prime = 31;

    for (char c : password) {
        hash = hash * prime + c;
        hash %= 1000000007;
    }

    return to_string(hash);
}

int main()
{



    file();
    client s1;
    char choice;
    char choice2;
   

    cout << "Welcome To Georges charity\n";


    do {
        cout << "Do you already have an account y|n: ";
        cin >> choice;
        if (choice == 'y') {
            cout << "please enter your login info: \n";
            string password;
            int id;
            do {
                cout << "id: ";

                cin >> id;
            } while (id < 0 || id>1000);


            cout << "Password: ";
            cin.ignore();
            getline(cin, password);


            int isAdmin = authentication(id, password);
            bool found;

            if (isAdmin == 1) {

                administrator();
            }
            else if (isAdmin == 2) {
                Client(s1);
            }
            else if (isAdmin == 0) {
                cout << "User does not exist. Authentication failed.\n";
                cout << "Would you like to create an account y|n:";
                cin >> choice2;
                if (choice2 == 'y') {
                    account(s1);

                }
                else if (choice2 == 'n') {
                    return 0;
                }
            }

        }
        if (choice == 'n') {

            cout << "Would you like to create an account y|n:";
            cin >> choice2;
            if (choice2 == 'y') {
                account(s1);
            }
            else if (choice2 == 'n') {
                return 0;
            }
        }

    } while (choice != 'n' && choice != 'y');

}